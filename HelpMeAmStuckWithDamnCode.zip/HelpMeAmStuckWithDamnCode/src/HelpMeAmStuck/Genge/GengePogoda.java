package HelpMeAmStuck.Genge;

public class GengePogoda {
//Zgubiłem klucz ddo api o pogodzie
}
