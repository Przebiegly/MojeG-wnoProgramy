package HelpMeAmStuck.Othere;

import java.util.List;

public class Numbers {
    private static String[] StringNumberTab = {"1","2","3","4","5","6","7","8","9","0","."};
    public static List<String> ListNumbers = List.of(StringNumberTab);

}
