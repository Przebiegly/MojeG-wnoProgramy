package HelpMeAmStuck.Othere;

public class Names {

    public static String[] NamesList = {"Jan.db", "Adam", "Adrian", "Jakub", "Aleksander", "Bartosz", "Paweł", "Grzegorz", "Kacper", "Łukasz", "Mateusz", "Michał", "Janusz", "Piotr", "Tomasz", "Krzysztof", "Szymon", "Rafał", "Marek", "Robert", "Ireneusz", "Konrad", "Wojciech", "Maciej", "Cezary", "Jacek"};
    public static String[] SureNamesList = {"Kowalski", "Nowak", "Wiśniewski", "Wójcik", "Kowalczyk", "Kamiński", "Lewandowski", "Zieliński", "Szymański", "Woźniak", "Dąbrowski", "Kozłowski", "Jankowski", "Mazur", "Krawczyk", "Piotrowski", "Grabowski", "Nowakowski", "Pawłowski", "Michalski", "Nowicki", "Adamczyk", "Sikora", "Włodarczyk", "Król", "Jaworski", "Malinowski", "Kaczmarek"};



}
