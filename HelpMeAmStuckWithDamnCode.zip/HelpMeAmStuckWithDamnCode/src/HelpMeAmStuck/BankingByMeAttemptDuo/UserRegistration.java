package HelpMeAmStuck.BankingByMeAttemptDuo;

public class UserRegistration {
    private Database database;

    public UserRegistration(Database database) {
        this.database = database;
    }

    public boolean registerUser(User user) {
        // Write code to insert the user data into the "users" table
        // Use database.createStatement() to execute SQL statements
        // Return true if registration is successful, false otherwise
        return false;
    }
}
