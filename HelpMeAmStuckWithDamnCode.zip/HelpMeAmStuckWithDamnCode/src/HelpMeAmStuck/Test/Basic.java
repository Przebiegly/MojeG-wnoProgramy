package HelpMeAmStuck.Test;


public class Basic {
    public static int add(int a, int b) {
        return a + b;
    }
}
