package HelpMeAmStuck.DisplayInfo;

public class DisplayInfo {
    public static void Info(){
        System.out.println("Valid Commands: \n" +
                "\n" +
                "end/exit/quit -> Gets Back to previous program state or shuts down existing process\n" +
                "\n" +
                "test1 -> Runs a basic test\n" +
                "Sym -> Runs program SymetralnaOdcinka Can Be accessed from Other Calculators\n" +
                "Cal -> Runs default Calculator, Contains access to other math related programs");
    }
}
