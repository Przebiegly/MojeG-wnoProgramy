import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean end = false;
        String word = "";

        int coin = 0;

        int i = 0;
        int change;
        int prize = 1;
        int reszta = 0;
        String font = ": -------->";
        List<Integer> list=new ArrayList<Integer>();

        System.out.println(font);

        while(!end){

            System.out.print(":> ");
            word = sc.next();

            if(word.equals("q")){
                end = true;
                continue;
            }

            coin = Integer.parseInt(word);
            if(coin<=0){
                end = true;
                System.out.println("Not for U");
                continue;

            }

            if(coin == prize) {
                list.add(coin);
                i++;
                System.out.println(": Sold");
            }else{
                int b = 0 ;
                change = coin - prize;
                reszta = change / prize;
                for(int c = 0; c < list.size(); c++){
                    int placeholder;
                    placeholder = list.get(c);
                    if(placeholder == reszta){
                        c = list.size();
                        b = list.get(c);
                        list.remove(c);
                        list.add(coin);

                    } else if (placeholder < reszta) {
                        b = b + list.get(c);
                        list.remove(c);
                        c--;

                    }

                    if(b == reszta){
                        c = list.size();
                    }

                }
                //System.out.println("reszta = "+reszta+" wypłacona w monetach ");




            }

            System.out.println(list);
            System.out.println(font);
        }





    }
}
